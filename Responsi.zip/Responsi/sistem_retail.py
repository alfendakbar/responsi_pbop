import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from datetime import datetime

# Database connection
class Database:
    def __init__(self):
        self.connection = mysql.connector.connect(
            host="localhost",
            user="root",
            password="",  # Replace with your MySQL password
            database="sistemretail_db"
        )
        self.cursor = self.connection.cursor()

    def execute_query(self, query, params=None):
        try:
            self.cursor.execute(query, params)
            self.connection.commit()
        except mysql.connector.Error as e:
            messagebox.showerror("Database Error", str(e))

    def fetch_query(self, query, params=None):
        self.cursor.execute(query, params)
        return self.cursor.fetchall()

    def close_connection(self):
        self.cursor.close()
        self.connection.close()

# Main Application
class App:
    def __init__(self, root):
        self.db = Database()
        self.root = root
        self.root.title("Produk dan Transaksi Management")

        # Tabs
        self.tab_control = ttk.Notebook(root)
        self.tab_produk = ttk.Frame(self.tab_control)
        self.tab_transaksi = ttk.Frame(self.tab_control)

        self.tab_control.add(self.tab_produk, text="Produk")
        self.tab_control.add(self.tab_transaksi, text="Transaksi")
        self.tab_control.pack(expand=1, fill="both")

        # Produk Tab
        self.setup_produk_tab()

        # Transaksi Tab
        self.setup_transaksi_tab()

    def setup_produk_tab(self):
        # Produk Form
        ttk.Label(self.tab_produk, text="Nama Produk:").grid(row=0, column=0, padx=10, pady=5)
        self.nama_produk = ttk.Entry(self.tab_produk)
        self.nama_produk.grid(row=0, column=1, padx=10, pady=5)

        ttk.Label(self.tab_produk, text="Harga Produk:").grid(row=1, column=0, padx=10, pady=5)
        self.harga_produk = ttk.Entry(self.tab_produk)
        self.harga_produk.grid(row=1, column=1, padx=10, pady=5)

        # Buttons in a single row
        frame_buttons = ttk.Frame(self.tab_produk)
        frame_buttons.grid(row=2, column=0, columnspan=2, pady=10)

        ttk.Button(frame_buttons, text="Tambah Produk", command=self.create_produk).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_buttons, text="Update Produk", command=self.update_produk).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_buttons, text="Hapus Produk", command=self.delete_produk).pack(side=tk.LEFT, padx=5)

        # Produk List
        self.produk_tree = ttk.Treeview(self.tab_produk, columns=("ID", "Nama", "Harga"), show="headings")
        self.produk_tree.heading("ID", text="ID Produk")
        self.produk_tree.heading("Nama", text="Nama Produk")
        self.produk_tree.heading("Harga", text="Harga")
        self.produk_tree.grid(row=3, column=0, columnspan=2, padx=10, pady=10)
        self.produk_tree.bind("<ButtonRelease-1>", self.fill_produk_form)

        self.refresh_produk_list()

    def setup_transaksi_tab(self):
        # Transaksi Form
        ttk.Label(self.tab_transaksi, text="Pilih Produk:").grid(row=0, column=0, padx=10, pady=5)
        self.produk_combobox = ttk.Combobox(self.tab_transaksi)
        self.produk_combobox.grid(row=0, column=1, padx=10, pady=5)

        ttk.Label(self.tab_transaksi, text="Jumlah:").grid(row=1, column=0, padx=10, pady=5)
        self.jumlah_produk = ttk.Entry(self.tab_transaksi)
        self.jumlah_produk.grid(row=1, column=1, padx=10, pady=5)

        ttk.Label(self.tab_transaksi, text="Total Harga:").grid(row=2, column=0, padx=10, pady=5)
        self.total_harga_label = ttk.Label(self.tab_transaksi, text="0")
        self.total_harga_label.grid(row=2, column=1, padx=10, pady=5)

        # Buttons
        frame_buttons = ttk.Frame(self.tab_transaksi)
        frame_buttons.grid(row=4, column=0, columnspan=2, pady=10)

        ttk.Button(frame_buttons, text="Simpan Transaksi", command=self.create_transaksi).pack(side=tk.LEFT, padx=5)
        ttk.Button(frame_buttons, text="Hapus Transaksi", command=self.delete_transaksi).pack(side=tk.LEFT, padx=5)

        # Transaksi List
        self.transaksi_tree = ttk.Treeview(self.tab_transaksi, columns=("Nama", "Jumlah", "Total", "Tanggal"), show="headings")
        self.transaksi_tree.heading("Nama", text="Nama Produk")
        self.transaksi_tree.heading("Jumlah", text="Jumlah")
        self.transaksi_tree.heading("Total", text="Total Harga")
        self.transaksi_tree.heading("Tanggal", text="Tanggal Transaksi")
        self.transaksi_tree.grid(row=5, column=0, columnspan=2, padx=10, pady=10)

        # Bind event for automatically calculating total when quantity changes
        self.jumlah_produk.bind("<KeyRelease>", self.calculate_total)

        self.refresh_transaksi_list()
        self.refresh_produk_combobox()

    def create_produk(self):
        nama = self.nama_produk.get()
        harga = self.harga_produk.get()

        if not nama or not harga:
            messagebox.showerror("Error", "Silahkan Lengkapi Form Terlebih Dahulu!")
            return

        try:
            harga = float(harga)
            if harga < 0:
                raise ValueError("Harga harus positif.")

            query = "INSERT INTO produk (nama_produk, harga_produk) VALUES (%s, %s)"
            self.db.execute_query(query, (nama, harga))
            messagebox.showinfo("Sukses", "Produk berhasil ditambahkan.")
            self.refresh_produk_list()
            self.refresh_produk_combobox()
            self.clear_produk_form()

        except ValueError:
            messagebox.showerror("Error", "Format Harga Produk salah, silahkan coba lagi!")

    def update_produk(self):
        selected_item = self.produk_tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Pilih produk yang ingin diupdate.")
            return

        nama = self.nama_produk.get()
        harga = self.harga_produk.get()

        if not nama or not harga:
            messagebox.showerror("Error", "Silahkan Lengkapi Form Terlebih Dahulu!")
            return

        try:
            item = self.produk_tree.item(selected_item)
            produk_id = item['values'][0]
            harga = float(harga)

            if harga < 0:
                raise ValueError("Harga harus positif.")

            query = "UPDATE produk SET nama_produk = %s, harga_produk = %s WHERE id_produk = %s"
            self.db.execute_query(query, (nama, harga, produk_id))
            messagebox.showinfo("Sukses", "Produk berhasil diupdate.")
            self.refresh_produk_list()
            self.refresh_produk_combobox()
            self.clear_produk_form()

        except ValueError:
            messagebox.showerror("Error", "Format Harga Produk salah, silahkan coba lagi!")

    def create_transaksi(self):
        selected = self.produk_combobox.get()
        if not selected:
            messagebox.showerror("Error", "Pilih produk terlebih dahulu.")
            return

        try:
            jumlah = int(self.jumlah_produk.get())
            if jumlah <= 0:
                raise ValueError("Jumlah harus positif.")

            total_harga = float(self.total_harga_label.cget("text"))
            produk_id = int(selected.split(" - ")[0])
            tanggal_transaksi = datetime.now().strftime("%Y-%m-%d")

            query = "INSERT INTO transaksi (id_produk, jumlah_produk, total_harga, tanggal_transaksi) VALUES (%s, %s, %s, %s)"
            self.db.execute_query(query, (produk_id, jumlah, total_harga, tanggal_transaksi))
            messagebox.showinfo("Sukses", "Transaksi berhasil disimpan.")
            self.refresh_transaksi_list()
            self.clear_transaksi_form()

        except ValueError:
            messagebox.showerror("Error", "Format Harga Produk salah, silahkan coba lagi!")

    def clear_produk_form(self):
        self.nama_produk.delete(0, tk.END)
        self.harga_produk.delete(0, tk.END)

    def clear_transaksi_form(self):
        self.produk_combobox.set("")
        self.jumlah_produk.delete(0, tk.END)
        self.total_harga_label.config(text="0")

    def fill_produk_form(self, event):
        selected_item = self.produk_tree.selection()
        if selected_item:
            item = self.produk_tree.item(selected_item)
            self.nama_produk.delete(0, tk.END)
            self.nama_produk.insert(0, item['values'][1])
            self.harga_produk.delete(0, tk.END)
            self.harga_produk.insert(0, item['values'][2])

    def refresh_produk_list(self):
        for i in self.produk_tree.get_children():
            self.produk_tree.delete(i)

        query = "SELECT * FROM produk"
        rows = self.db.fetch_query(query)
        for row in rows:
            self.produk_tree.insert("", "end", values=row)

    def delete_produk(self):
        selected_item = self.produk_tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Pilih produk yang ingin dihapus.")
            return

        item = self.produk_tree.item(selected_item)
        produk_id = item['values'][0]

        # First, delete related transactions
        query = "DELETE FROM transaksi WHERE id_produk = %s"
        self.db.execute_query(query, (produk_id,))

        # Then, delete the product
        query = "DELETE FROM produk WHERE id_produk = %s"
        self.db.execute_query(query, (produk_id,))

        messagebox.showinfo("Sukses", "Produk dan transaksi terkait berhasil dihapus.")
        self.refresh_produk_list()
        self.refresh_produk_combobox()

    def refresh_produk_combobox(self):
        query = "SELECT id_produk, nama_produk FROM produk"
        rows = self.db.fetch_query(query)
        self.produk_combobox['values'] = [f"{row[0]} - {row[1]}" for row in rows]

    def calculate_total(self, event=None):
        selected = self.produk_combobox.get()
        if not selected:
            self.total_harga_label.config(text="0")
            return

        try:
            jumlah = self.jumlah_produk.get()
            if not jumlah:
                self.total_harga_label.config(text="0")
                return

            jumlah = int(jumlah)
            if jumlah <= 0:
                raise ValueError("Jumlah harus positif.")

            produk_id = int(selected.split(" - ")[0])
            query = "SELECT harga_produk FROM produk WHERE id_produk = %s"
            harga_produk = self.db.fetch_query(query, (produk_id,))[0][0]

            total_harga = jumlah * harga_produk
            self.total_harga_label.config(text=str(total_harga))

        except ValueError:
            messagebox.showerror("Error", "Format Jumlah Produk salah, silahkan coba lagi!")
            self.total_harga_label.config(text="0")

    def delete_transaksi(self):
        selected_item = self.transaksi_tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Pilih transaksi yang ingin dihapus.")
            return

        item = self.transaksi_tree.item(selected_item)
        nama_produk, jumlah, total, tanggal = item['values']

        query = "DELETE FROM transaksi WHERE id_produk = (SELECT id_produk FROM produk WHERE nama_produk = %s) AND jumlah_produk = %s AND total_harga = %s AND tanggal_transaksi = %s"
        self.db.execute_query(query, (nama_produk, jumlah, total, tanggal))

        messagebox.showinfo("Sukses", "Transaksi berhasil dihapus.")
        self.refresh_transaksi_list()

    def refresh_transaksi_list(self):
        for i in self.transaksi_tree.get_children():
            self.transaksi_tree.delete(i)

        query = "SELECT p.nama_produk, t.jumlah_produk, t.total_harga, t.tanggal_transaksi FROM transaksi t JOIN produk p ON t.id_produk = p.id_produk"
        rows = self.db.fetch_query(query)
        for row in rows:
            self.transaksi_tree.insert("", "end", values=row)

if __name__ == "__main__":
    root = tk.Tk()
    app = App(root)
    root.mainloop()
